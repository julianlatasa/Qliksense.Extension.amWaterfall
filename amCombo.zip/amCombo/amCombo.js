requirejs.config({
    paths: {
        "amcharts": "/extensions/amCombo/library/amcharts",
        "amcharts.serial": "/extensions/amCombo/library/serial",
    },
    shim: {
        "amcharts.serial": {
            deps: ["amcharts"],
            exports: "AmCharts",
            init: function() {
                AmCharts.isReady = true;
            }
        }
    }
});
define([
        'qlik',
        'jquery',
        './properties',
        'amcharts.serial'
    ],
    function(qlik, $, props) {
        return {
            definition: props,
            initialProperties: {
                qHyperCubeDef: {
                    qDimensions: [],
                    qMeasures: [],
                    qInitialDataFetch: [{
                        qWidth: 6,
                        qHeight: 1500
                    }]
                }
            },
            paint: function($element, layout) {
                var self = this;
                var hc = layout.qHyperCube;
                var dataProvider = [];
                var dataProviderStart = {};
                var dataProviderEnd = {};
                var trendLines = [];
                var trendLinesEnd = {};
                var amGraphs = [];
                hc.qDataPages.forEach(function(page, index) {

                    page.qMatrix.forEach(function(row, rindex) {
                        var dataProviderObj = {};
                        var trendLinesObj = {};

                        row.forEach(function(cell, index) {
                            var cId;
                            if (index < hc.qDimensionInfo.length) {

                                cId = hc.qDimensionInfo[index].cId;
                                dataProviderObj["elemNumber" + cId] = cell.qElemNumber;
                                dataProviderObj["text" + cId] = cell.qText;
                                dataProviderObj.dimText = cell.qText;
                            } else {
                                cId = hc.qMeasureInfo[index - hc.qDimensionInfo.length].cId;

                                // Create initial object for start values (waterfall)
                                if (rindex === 0 && hc.qMeasureInfo[index - hc.qDimensionInfo.length].amGraph.type == 'Waterfall') {

                                    dataProviderStart["text" + hc.qDimensionInfo[0].cId] = hc.qMeasureInfo[index - hc.qDimensionInfo.length].waterfall.startLabel;
                                    dataProviderStart["text" + cId] = hc.qMeasureInfo[index - hc.qDimensionInfo.length].waterfall.start;
                                    dataProviderStart["elemNumber" + hc.qDimensionInfo[0].cId] = 0;
                                    dataProviderStart["open" + cId] = 0;
                                    dataProviderStart["close" + cId] = hc.qMeasureInfo[index - hc.qDimensionInfo.length].waterfall.start;
                                    dataProviderStart["color" + cId] = "#1c8ceb";
                                    dataProviderStart.dimText = hc.qMeasureInfo[index - hc.qDimensionInfo.length].waterfall.startLabel;
                                    dataProvider.push(dataProviderStart);
                                }

                                // Create last object for end values (waterfall)
                                if (rindex == hc.qSize.qcy - 1 && hc.qMeasureInfo[index - hc.qDimensionInfo.length].amGraph.type == 'Waterfall') {

                                    dataProviderEnd["text" + hc.qDimensionInfo[0].cId] = hc.qMeasureInfo[index - hc.qDimensionInfo.length].waterfall.endLabel;
                                    dataProviderEnd["text" + cId] = hc.qMeasureInfo[index - hc.qDimensionInfo.length].waterfall.end;
                                    dataProviderEnd["elemNumber" + hc.qDimensionInfo[0].cId] = 0;
                                    dataProviderEnd["open" + cId] = 0;
                                    dataProviderEnd["close" + cId] = hc.qMeasureInfo[index - hc.qDimensionInfo.length].waterfall.end;
                                    dataProviderEnd["color" + cId] = "#1c8ceb";
                                    dataProviderEnd.dimText = hc.qMeasureInfo[index - hc.qDimensionInfo.length].waterfall.endLabel;
                                }

                                dataProviderObj["text" + cId] = cell.qText;

                                if (hc.qMeasureInfo[index - hc.qDimensionInfo.length].amGraph.type == 'Waterfall') {
                                    dataProviderObj["open" + cId] = dataProvider[rindex]["close" + cId];
                                    if (dataProviderObj["open" + cId] + cell.qNum > dataProvider[rindex]["close" + cId]) {
                                        dataProviderObj["color" + cId] = "#54cb6a";
                                    } else {
                                        dataProviderObj["color" + cId] = "#cc4b48";
                                    }
                                } else {
                                    dataProviderObj["open" + cId] = 0;
                                }

                                if (hc.qMeasureInfo[index - hc.qDimensionInfo.length].amGraph.type == 'Waterfall') {
                                    trendLinesObj.dashLength = 3;
                                    trendLinesObj.finalCategory = dataProviderObj.dimText;
                                    trendLinesObj.initialCategory = dataProvider[rindex].dimText;
                                    trendLinesObj.initialValue = dataProvider[rindex]["close" + hc.qMeasureInfo[index - hc.qDimensionInfo.length].cId];
                                    trendLinesObj.lineColor = "#888888";
                                    trendLinesObj.finalValue = dataProviderObj["open" + cId];
                                    trendLines.push(trendLinesObj);

                                    //add last trend line (waterfall)
                                    if (rindex == hc.qSize.qcy - 1) {
                                        trendLinesEnd.dashLength = 3;
                                        trendLinesEnd.finalCategory = hc.qMeasureInfo[index - hc.qDimensionInfo.length].waterfall.endLabel;
                                        trendLinesEnd.initialCategory = dataProviderObj.dimText;
                                        trendLinesEnd.initialValue = dataProviderObj["open" + cId] + cell.qNum;
                                        trendLinesEnd.lineColor = "#888888";
                                        trendLinesEnd.finalValue = hc.qMeasureInfo[index - hc.qDimensionInfo.length].waterfall.end;
                                        console.log(trendLinesEnd);
                                        trendLines.push(trendLinesEnd);
                                    }
                                }

                                dataProviderObj["close" + cId] = dataProviderObj["open" + cId] + cell.qNum;
                            }
                            if (cell.qNum == 'NaN') {
                                dataProviderObj[cId] = cell.qText;
                            } else {
                                dataProviderObj[cId] = cell.qNum;
                            }

                        });
                        dataProvider.push(dataProviderObj);
                    });
                    var waterfallCount = 0;
                    hc.qMeasureInfo.forEach(function(mes, index) {
                        if (mes.amGraph.type == 'Waterfall') {
                            waterfallCount++;
                        }
                    });
                    if (waterfallCount > 0) {
                        dataProvider.push(dataProviderEnd);
                    }
                });
                hc.qMeasureInfo.forEach(function(measureDef, index) {
                    var amGraph = {};
                    if (measureDef.amGraph.type == 'Waterfall') {
                        amGraph.type = 'column';
                        amGraph.colorField = 'color' + measureDef.cId;
                        amGraph.lineColor = '#BBBBBB';
                    } else {
                        amGraph.type = measureDef.amGraph.type;
                        amGraph.fillColors = measureDef.amGraph.fillColors;
                        amGraph.lineColor = measureDef.amGraph.lineColor;
                    }
                    if (measureDef.amGraph.showLabel === true) {
                        amGraph.labelText = "[[text" + measureDef.cId + "]]";
                    }
                    amGraph.id = measureDef.cId;
                    amGraph.openField = "open" + measureDef.cId;
                    amGraph.valueField = "close" + measureDef.cId;
                    amGraph.title = hc.qMeasureInfo[index].qFallbackTitle;
                    amGraph.bulletBorderAlpha = 1;
                    amGraph.hideBulletsCount = 50;
                    amGraph.useLineColorForBulletBorder = true;
                    amGraph.balloonText = "<b>[[title]]</b><br/>[[text" + measureDef.cId + "]]";
                    amGraph.valueAxis = measureDef.amGraph.valueAxis;
                    amGraph.fillAlphas = measureDef.amGraph.fillAlphas;
                    amGraph.fontSize = measureDef.amGraph.fontSize;
                    amGraph.columnWidth = measureDef.amGraph.columnWidth;
                    amGraph.clustered = measureDef.amGraph.clustered;
                    amGraph.lineThickness = measureDef.amGraph.lineThickness;
                    amGraph.dashLength = measureDef.amGraph.dashLength;
                    amGraph.bullet = measureDef.amGraph.bullet;
                    amGraph.bulletAlpha = measureDef.amGraph.bulletAlpha;
                    amGraph.bulletColor = measureDef.amGraph.bulletColor;
                    amGraph.bulletSize = measureDef.amGraph.bulletSize;
                    amGraph.labelOffset = measureDef.amGraph.labelOffset;
                    amGraph.labelPosition = measureDef.amGraph.labelPosition;
                    amGraph.labelRotation = measureDef.amGraph.labelRotation;
                    amGraph.behindColumns = measureDef.amGraph.behindColumns;
                    amGraphs.push(amGraph);
                });

                var chart = AmCharts.makeChart($element[0], {
                    "type": "serial",
                    "theme": "none",
                    "depth3D": layout.amChart.depth3D,
                    "angle": layout.amChart.angle,
                    "fontFamily": layout.amChart.fontFamily,
                    "fontSize": layout.amChart.fontSize,
                    "handDrawn": layout.amChart.handDrawn,
                    "precision": 2,
                    "titles": [{
                        text: layout.amChart.titles.text,
                        alpha: layout.amChart.titles.alpha,
                        bold: layout.amChart.titles.bold,
                        color: layout.amChart.titles.color,
                        size: layout.amChart.titles.size
                    }],
                    "valueAxes": [{
                        "id": "v1",
                        "position": "left",
                        "autoGridCount": false,
                        "stackType": layout.amChart.valueAxis.leftStackType,
                        "fontSize": layout.amChart.valueAxis.fontSize,
                        "title": layout.amChart.valueAxis.leftTitle
                    }, {
                        "id": "v2",
                        "position": "right",
                        "autoGridCount": false,
                        "stackType": layout.amChart.valueAxis.rightStackType,
                        "fontSize": layout.amChart.valueAxis.fontSize,
                        "title": layout.amChart.valueAxis.rightTitle
                    }],
                    "graphs": amGraphs,
                    "trendLines": trendLines,
                    "chartCursor": {
                        "selectWithoutZooming": true,
                        "pan": false,
                        "valueLineEnabled": true,
                        "valueLineBalloonEnabled": true,
                        "cursorAlpha": 0,
                        "valueLineAlpha": 0.2
                    },
                    "categoryField": "text" + hc.qDimensionInfo[0].cId,
                    "categoryAxis": {
                        "parseDates": false,
                        "dashLength": 1,
                        "minorGridEnabled": true,
                        "labelRotation": layout.amChart.categoryAxis.labelRotation,
                        "fontSize": layout.amChart.categoryAxis.fontSize,
                        "title": layout.amChart.categoryAxis.title
                    },
                    "legend": {
                        "equalWidths": false,
                        "useGraphSettings": true,
                        "enabled": layout.amChart.legend.enabled,
                        "position": layout.amChart.legend.position
                    },
                    "balloon": {
                        "enabled": layout.amChart.balloon.enabled
                    },
                    "export": {
                        "enabled": true
                    },
                    "dataProvider": dataProvider
                });
                if (layout.amChart.handDrawn) {
                    $element.find("*").css("font-family", "Kristen ITC");
                } else {
                    $element.find("*").css("font-family", layout.amChart.fontFamily);
                }

                chart.chartCursor.addListener("selected", zoomy);
                function zoomy(zomzom) {
                    var dimValArray = [];
                    dataProvider.forEach(function(row,index) {
                        if(index >= zomzom.start && index <= zomzom.end && row["elemNumber" + hc.qDimensionInfo[0].cId] > 0) {
                            dimValArray.push(row["elemNumber" + hc.qDimensionInfo[0].cId]);
                        }
                    });
                    self.selectValues(0, dimValArray, false);
                }

                chart.addListener("clickGraphItem", handleClickGraphItem);
                function handleClickGraphItem(event) {
                    var dimValArray = [];
                        if(dataProvider[event.index]["elemNumber" + hc.qDimensionInfo[0].cId] > 0) {
                            dimValArray.push(dataProvider[event.index]["elemNumber" + hc.qDimensionInfo[0].cId]);
                        }
                    self.selectValues(0, dimValArray, false);
                }
            }

        };

    });
